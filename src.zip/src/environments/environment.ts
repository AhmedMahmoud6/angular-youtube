export const environment = {
  production: false,
  apiKey: 'AIzaSyDWsKhi_G5QGsBNKcCpXmf7ARoU19ues2M',
  videosUrl: `https://www.googleapis.com/youtube/v3`,
  channelUrl: 'https://www.googleapis.com/youtube/v3/channels'
};
