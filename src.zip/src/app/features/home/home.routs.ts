import {Routes} from '@angular/router';
import {Home} from './home';

export const HOME_ROUTES: Routes = [
  {
    path: "",
    component: Home
  }
]
