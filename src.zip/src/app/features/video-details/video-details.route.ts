import {Routes} from '@angular/router';
import {VideoDetails} from './video-details';

export const VIDEO_DETAILS_ROUTES: Routes = [
  {
    path: "",
    component: VideoDetails
  }
]
